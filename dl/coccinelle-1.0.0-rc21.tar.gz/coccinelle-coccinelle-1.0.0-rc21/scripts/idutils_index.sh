#!/bin/sh

mkid -i C --output .id-utils.index *
