int main() {
  f(12);
}
