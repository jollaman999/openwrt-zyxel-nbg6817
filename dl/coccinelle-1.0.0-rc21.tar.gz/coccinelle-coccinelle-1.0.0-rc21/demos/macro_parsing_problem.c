// note that some of our heuristics can deal with statement
// without trailing ';', but currently our heuristics don't handle
// those cases below:

int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}


int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}

int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}

int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}

int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}

int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
int main(void)
{
        /* Notice that there is NO semicolon at the end of next line. */
        char *buf = MALLOC(3)
        return 0;
}
