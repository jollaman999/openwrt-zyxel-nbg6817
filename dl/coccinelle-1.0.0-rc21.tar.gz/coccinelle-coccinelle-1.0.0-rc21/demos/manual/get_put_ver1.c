void main(int i)
{

  get();
  if(1) {
    put();
    return 0;
  }
  put();
}
