void main()
{
	g();
	foo();
	g();
	foo();

}
