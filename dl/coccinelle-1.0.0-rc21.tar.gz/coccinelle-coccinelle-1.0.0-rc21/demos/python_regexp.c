int main()
{
	int x;

	x = foo();
	x = foo_new();
	x = bar();
}
