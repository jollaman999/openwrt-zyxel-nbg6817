int main () {
  f(one);
  f(two);
  f(three);
  f(four);
  f(five);
}
