typedef struct foo { int a; } foo_t;

int main() {
  struct foo *a;
  foo_t *b;
  foo_t *c;

  xxx(a);
  yyy(b);
}

