int main () {
  ((struct xxx *)E)->foo = 12;
}
