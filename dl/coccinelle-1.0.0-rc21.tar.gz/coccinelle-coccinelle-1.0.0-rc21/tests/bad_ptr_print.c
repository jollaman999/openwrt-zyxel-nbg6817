static inline int tester(struct usb_endpoint_descriptor *epd)
{
  f((struct foo *)x);
}
