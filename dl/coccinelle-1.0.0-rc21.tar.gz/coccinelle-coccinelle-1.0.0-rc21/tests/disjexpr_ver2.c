int main (int i) {
 f(v.fld, v.fld2, v);
}
