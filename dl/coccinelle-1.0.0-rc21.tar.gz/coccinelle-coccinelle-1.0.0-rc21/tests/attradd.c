int main () {
  char f;
}
