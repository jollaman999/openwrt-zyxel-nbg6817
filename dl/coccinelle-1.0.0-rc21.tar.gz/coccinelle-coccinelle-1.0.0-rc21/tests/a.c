int main () {
  int a;
  f(a);
  h(a);
  { int a;
  g(a);
  r(a);
  }
}
