int main() {
  x = 12;
  x = x + 1;
}

int badmain() {
  x = 12;
  x = 1;
}
