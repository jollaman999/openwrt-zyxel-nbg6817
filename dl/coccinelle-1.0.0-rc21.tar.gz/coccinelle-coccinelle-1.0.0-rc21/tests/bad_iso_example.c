int main() {
  if ((x = 3)) return;
}

