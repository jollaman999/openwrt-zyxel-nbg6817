static struct usb_serial_device_type cp2101_device = {
	.owner			= THIS_MODULE,
	.name			= "CP2101",
};
