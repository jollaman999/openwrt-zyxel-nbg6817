int f(int x) {
  static int y;
  return x;
}
