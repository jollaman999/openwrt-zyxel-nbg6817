int main () {
  int *x;
  int x;
  return x;
}
