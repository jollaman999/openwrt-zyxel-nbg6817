int main () {
  int   a   ;
  int   b, c   ;
}
