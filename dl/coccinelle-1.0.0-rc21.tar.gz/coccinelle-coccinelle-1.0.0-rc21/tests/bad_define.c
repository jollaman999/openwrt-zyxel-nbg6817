#define x a + b
