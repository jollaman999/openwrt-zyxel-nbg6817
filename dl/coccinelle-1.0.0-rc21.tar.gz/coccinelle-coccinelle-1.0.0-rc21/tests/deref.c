int main () {
  int **q;
  foo(*q+12);
  xxx(q[0]+12);
  yyy(q+12);
}
