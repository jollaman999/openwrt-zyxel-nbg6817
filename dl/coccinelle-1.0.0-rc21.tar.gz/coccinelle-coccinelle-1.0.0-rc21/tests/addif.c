static int foo() {
  return 12;
}

static int bar() {
  return 12;
}
