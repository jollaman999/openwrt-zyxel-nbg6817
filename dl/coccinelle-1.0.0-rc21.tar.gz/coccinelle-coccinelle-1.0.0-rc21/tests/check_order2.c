int main () {
  g(five);
  g(four);
  g(three);
  g(two);
  g(one);
  f(one, 1);
  f(two, 2);
  f(three, 3);
  f(four, 4);
  f(five, 5);
  f(one, 10);
  f(two, 20);
  f(three, 30);
  f(four, 40);
  f(five, 50);
}
