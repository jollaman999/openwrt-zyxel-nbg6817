int main() {
  if (foo() && (x < 12)) return;
}
