MODULE_PARM_DESC(devices, "number of dsp devices allocated by the driver");
module_param(devices, int, 0);
