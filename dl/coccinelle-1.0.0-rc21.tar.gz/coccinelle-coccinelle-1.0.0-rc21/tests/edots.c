void main(int i) {
  foo[45];
  bar[45+v.field];

  //  f(foo[45] + bar[45]);

}
