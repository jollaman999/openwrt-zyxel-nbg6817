int main () {
  if (a) {
    bar();
  }
}
