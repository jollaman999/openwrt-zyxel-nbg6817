int main(int x) {
  int x = 100;
  x = 45;
}
