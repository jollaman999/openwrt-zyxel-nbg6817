int main () {
  if (x)
    xxx();
  else
    xxx();
}
