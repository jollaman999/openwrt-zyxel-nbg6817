void foo(int j) { 
  const char *i;
  int i;
  i++;
}
