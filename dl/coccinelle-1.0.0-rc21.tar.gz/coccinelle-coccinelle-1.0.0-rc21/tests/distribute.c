int main(int i) { 

  f(1+1);
}
