static int az_ioctl(int cmd, void *arg)
{
  if (x) {
    return 0;
  }
  else {
    return 0;
  }
}

