int f(char *x, int y, char* z) {
  return;
}

int g(char *x, int y, char* z) {
  return;
}


void main(void)
{
	g("toto", 3, "tata");
}
