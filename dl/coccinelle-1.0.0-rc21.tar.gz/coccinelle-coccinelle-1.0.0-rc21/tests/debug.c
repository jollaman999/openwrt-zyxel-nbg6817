static int __init init_3c574_cs(void)
{
    DEBUG(0, "%s\n", version);
    return 0;
}
