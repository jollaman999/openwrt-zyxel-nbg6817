int main(int q[1024])
{ return 12; }

int fn(int q[])
{ return 12; }

