#define PRINTK(x) printk x

#include "foo.h"

int main () {
  printk("some stuff\n");
}
