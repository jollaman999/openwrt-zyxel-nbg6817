static int typhoon_ioctl(struct video_device *dev, unsigned int cmd,void *arg)
{
   struct typhoon_device *typhoon = dev->priv;
   return 0;
}
