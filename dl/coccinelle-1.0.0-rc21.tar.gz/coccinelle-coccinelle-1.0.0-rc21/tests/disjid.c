int foo (int x, int z) { return 0; }
int foo (int y, int z) { return 0; }
int bar (int x, int z) { return 0; }
int bar (int y, int z) { return 0; }
int xxx (int y, int z) { return 0; }
