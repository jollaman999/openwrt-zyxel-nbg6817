struct i2c_client I = {
       .name = E,
       .foo = 16,
};
