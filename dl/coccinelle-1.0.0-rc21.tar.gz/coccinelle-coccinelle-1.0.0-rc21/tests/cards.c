MODULE_PARM(io, "1-" __MODULE_STRING(MAX_CARDS) "i");

int x;
