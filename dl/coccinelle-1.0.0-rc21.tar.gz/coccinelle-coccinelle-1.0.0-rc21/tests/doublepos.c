int main() {
  f(1,2);
  f(1,5);
  f(6,5);
}

