int main () {
  foo = 5;
  a = 12;
  xxx = 12;
}
