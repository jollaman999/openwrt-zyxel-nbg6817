void main(int i){

  f(1,2,3);

  h(1,2);
  h();

}
