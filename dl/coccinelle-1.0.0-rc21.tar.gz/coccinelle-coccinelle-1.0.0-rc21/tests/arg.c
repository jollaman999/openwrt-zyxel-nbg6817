int main () {
  foo(bar());
  foo(1,bar());
  foo(bar(),2);
  foo(1,bar(),2);
}
